package com.carxx.goldsensi

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.credentials.Credential
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch

class MainActivity : Activity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var status: TextView

    // TODO: Replace with the Google account you control.
    // For real security, enforce admin status on a trusted backend / Firebase custom claims.
    private val adminEmail = "YOUR_ADMIN_GMAIL@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        buildScreen()
        updateStatus()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(15, 15, 18))
        }
        fun heading(text: String, size: Float) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(235, 190, 65))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 18)
        }
        fun action(label: String, onTap: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onTap() }
        }

        page.addView(heading("CARXX GOLD SENSI", 26f))
        page.addView(heading("GOLD PREMIUM GAMING ASSISTANT", 13f))
        page.addView(status)
        page.addView(action("SIGN IN WITH GOOGLE") { signInWithGoogle() })
        page.addView(action("ENABLE CROSSHAIR") { enableCrosshair() })
        page.addView(action("TURN OFF CROSSHAIR") {
            stopService(Intent(this, CrosshairService::class.java))
            toast("Crosshair OFF")
        })
        page.addView(action("GOLD PREMIUM — ₹10 (SETUP REQUIRED)") {
            toast("Add Play Console product gold_unlock_10 and verify purchases on a backend.")
        })
        page.addView(action("SIGN OUT") {
            auth.signOut()
            updateStatus()
        })
        page.addView(heading("Sensitivity tips are guides only. This app does not change game sensitivity automatically.", 12f))
        setContentView(page)
    }

    private fun signInWithGoogle() {
        val googleOption = GetGoogleIdOption.Builder()
            .setServerClientId(getString(R.string.default_web_client_id))
            .setFilterByAuthorizedAccounts(false)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleOption)
            .build()
        val manager = CredentialManager.create(this)

        lifecycleScope.launch {
            try {
                val result = manager.getCredential(this@MainActivity, request)
                handleGoogleCredential(result.credential)
            } catch (e: Exception) {
                toast("Google sign-in failed: ${e.localizedMessage ?: "Try again"}")
            }
        }
    }

    private fun handleGoogleCredential(credential: Credential) {
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            try {
                val google = GoogleIdTokenCredential.createFrom(credential.data)
                val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
                auth.signInWithCredential(firebaseCredential).addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) updateStatus()
                    else toast("Firebase login failed")
                }
            } catch (e: GoogleIdTokenParsingException) {
                toast("Could not read Google account")
            }
        } else {
            toast("Please choose a Google account")
        }
    }

    private fun updateStatus() {
        val user = auth.currentUser
        val isAdmin = user?.email.equals(adminEmail, ignoreCase = true)
        status.text = when {
            user == null -> "Not signed in"
            isAdmin -> "ADMIN ACCESS: ${user.email}"
            else -> "SIGNED IN: ${user.email}\nPremium access: not verified"
        }
    }

    private fun enableCrosshair() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            toast("Allow Display over other apps, then tap Enable Crosshair again")
            return
        }
        startService(Intent(this, CrosshairService::class.java))
        toast("Crosshair ON")
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
