package com.carxx.goldsensi

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class CrosshairService : Service() {
    private var windowManager: WindowManager? = null
    private var crosshair: TextView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        crosshair = TextView(this).apply {
            text = "+"
            textSize = 34f
            setTextColor(Color.GREEN)
            gravity = Gravity.CENTER
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        windowManager?.addView(crosshair, params)
    }

    override fun onDestroy() {
        crosshair?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Exception) { }
        }
        crosshair = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
