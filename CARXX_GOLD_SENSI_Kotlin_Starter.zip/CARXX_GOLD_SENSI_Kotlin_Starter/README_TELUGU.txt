CARXX GOLD SENSI — Kotlin starter project

ఇది ప్రారంభ Kotlin Android project మాత్రమే; పూర్తి Play Store-ready యాప్ కాదు.

తదుపరి సెటప్:
1. Android Studioలో ఈ project folder open చేయండి.
2. Firebase Consoleలో Android app package: com.carxx.goldsensi నమోదు చేయండి.
3. Firebase Authenticationలో Google provider enable చేయండి.
4. Firebase ఇచ్చే google-services.json ఫైల్‌ను app/ ఫోల్డర్‌లో పెట్టండి.
5. Firebase/Google Cloud OAuth సెటప్ చేసి default_web_client_id resource అందుబాటులో ఉందో చూడండి.
6. MainActivity.ktలో YOUR_ADMIN_GMAIL@gmail.com స్థానంలో మీ Admin Gmail పెట్టండి.
7. Productionలో admin roleను client-side email checkతో మాత్రమే భద్రపరచకండి; Firebase custom claims/secure backendతో enforce చేయండి.
8. Google Play Consoleలో gold_unlock_10 అనే one-time product సృష్టించి ధరను ₹10గా సెట్ చేయండి. Billing purchase flow, server-side purchase-token verification, acknowledgement మరియు entitlement storage ఇంకా అమలు చేయాలి.

గమనికలు:
- Overlay permission యూజర్ స్వయంగా Settingsలో allow చేయాలి.
- కొన్ని games overlayలను బ్లాక్ చేయవచ్చు లేదా అనుమతించకపోవచ్చు.
- ఈ app గేమ్ sensitivity/DPIని స్వయంగా మార్చదు; సూచనలు మాత్రమే చూపుతుంది.
- APK build చేయడానికి Android Studio + JDK అవసరం.
